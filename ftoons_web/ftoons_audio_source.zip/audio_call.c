
// The JS wrapper sets up the same far return and arguments as the Windows
// renderer. Only the verified game sequencer or ADL.DRV may execute.
extern void audio_chip_reset(void);
void audio_init(void) {
    init_cpu();
    audio_chip_reset();
}
int audio_call(unsigned offset) {
    sregs[SS] = 0x7000; wregs[SP] = 0xff00; wregs[BP] = 0;
    sregs[DS] = 0x567f; sregs[CS] = 0x3bea; ip = offset;
    for (unsigned i = 0; i < 2000000; ++i) {
        if (sregs[CS] == 0x60 && ip == 0) return wregs[AX];
        unsigned address = (unsigned)sregs[CS] * 16 + ip;
        if (!((address >= 0x3bea0 && address < 0x4bea0) ||
              (address >= 0x80000 && address < 0x84000))) return -1;
        next_instruction();
    }
    return -1;
}
