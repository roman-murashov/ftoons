#pragma once
#include <stdint.h>
#include <stddef.h>
namespace std { class ostream; class istream; }
using Bitu = uintptr_t;
using Bits = intptr_t;
#define INLINE inline
#define DB_FASTCALL
#define GCC_UNLIKELY(x) __builtin_expect(!!(x),0)
#define LOG_MSG(...)
class MixerChannel {public: virtual void AddSamples_m32(Bitu,const int32_t*)=0; virtual void AddSamples_s32(Bitu,const int32_t*)=0;};
