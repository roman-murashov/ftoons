#include "cpu.h"
#include <limits.h>
static uint8_t memory[1048576];
unsigned char *audio_mem(void) { return memory; }
#define debug(...)
#define bios_routine(x) __builtin_trap()
extern void audio_port(unsigned port, unsigned value);
#define write_port audio_port
static unsigned read_port(unsigned port) { (void)port; return 0; }
