// Use the production renderer's OPL clock, output gain, DC correction and
// linear interpolation. Digital RAW samples take Godot's regular PCM path.
#include "dbopl.h"
namespace DBOPL { void InitTables(); }
inline void* operator new(size_t, void* buffer) { return buffer; }
alignas(DBOPL::Chip) static uint8_t chip_storage[sizeof(DBOPL::Chip)];
static DBOPL::Chip *chip;
static int32_t previous, current;
static uint32_t phase, reg;
static int64_t dc;
static bool loaded;
static int16_t output[8192];
extern "C" void audio_chip_reset() {
    DBOPL::InitTables();
    __builtin_memset(chip_storage, 0, sizeof(chip_storage));
    chip = new(chip_storage) DBOPL::Chip(true);
    chip->Setup(49716);
    previous = current = phase = reg = dc = 0;
    loaded = false;
}
extern "C" void audio_port(unsigned port, unsigned value) {
    if (port == 0x388) reg = value;
    else if (port == 0x389) chip->WriteReg(reg, uint8_t(value));
    else __builtin_trap();
}
static int32_t chip_sample() {
    int32_t sample;
    chip->GenerateBlock2(1, &sample);
    return sample;
}
extern "C" int16_t *audio_render(unsigned length) {
    if (length > 8192) __builtin_trap();
    if (!loaded) { previous = chip_sample(); current = chip_sample(); loaded = true; }
    for (unsigned i = 0; i < length; ++i) {
        while (phase >= 48000) { phase -= 48000; previous = current; current = chip_sample(); }
        int32_t interpolated = previous + (int64_t(current - previous) * phase) / 48000;
        phase += 49716;
        int64_t value = int64_t(interpolated) * 12288 + dc;
        int speed = value > -(30000LL << 13) && value < (30000LL << 13) ? 1 : 64;
        dc -= (value * ((1 << 24) / 48000) * speed) >> 24;
        value >>= 13;
        output[i] = value < -32768 ? -32768 : value > 32767 ? 32767 : int16_t(value);
    }
    return output;
}
