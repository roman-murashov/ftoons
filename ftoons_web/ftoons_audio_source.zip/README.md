# Browser AdLib renderer

The JavaScript reader decodes the player's TOONS.SX bank at import time. When
Godot requests a score, it passes the decoded sequence, the player's original
DOS driver and instrument patch to a local WebAssembly renderer. The module
executes the game's hash-verified sequencer in isolated 1 MiB memory. Only
the AdLib register ports are connected. No DOS, filesystem, network or host
process calls are available to the sequencer.

The 80186 interpreter comes from [Daniel Serpell's emu2](https://github.com/dmsc/emu2/tree/master/src),
based on David Hedley's pcemu. The included upstream cpu.c has SHA-256
`dcd9a2e60223fd9291003da52c910971529cedfd0de95974ec14d34b0e771a74`.
The build omits the BIOS, Unix loop, debugging and command-line routines.
The DBOPL chip implementation comes from the same DOSBox-X source files as
the Windows ftoons renderer. Both components include their license in this archive.

To rebuild the module from the source archive, install Zig 0.15.2 and Python 3
and run `python build.py --zig /path/to/zig --dbopl dbopl --out output`.
No game data or build tools are required on the player's machine.
