"""Build the isolated browser audio core with Zig 0.15.2. Players need only a browser."""
import argparse
import hashlib
from pathlib import Path
import shutil
import subprocess
import tempfile
import zipfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[2] if len(HERE.parents) > 2 else HERE
parser = argparse.ArgumentParser()
parser.add_argument("--zig", default=str(next((REPO / "tools/zig-0.15.2").glob("*/zig.exe"), "zig")))
parser.add_argument("--dbopl", type=Path, default=REPO / "windows_build_production/native_audio/dbopl-source")
parser.add_argument("--out", type=Path, default=REPO / "windows_build_production/web_runtime")
args = parser.parse_args()
args.out = args.out.resolve()
args.dbopl = args.dbopl.resolve()
args.zig = shutil.which(args.zig) or str(Path(args.zig).resolve())
args.out.mkdir(parents=True, exist_ok=True)
with tempfile.TemporaryDirectory() as tmp:
    root = Path(tmp)
    # Keep the upstream instruction decoder. Replace Unix process/BIOS/IRQ
    # scheduling with our bounded call into a single DOS audio routine.
    src = (HERE / "emu2/cpu.c").read_bytes()
    assert hashlib.sha256(src).hexdigest() == "dcd9a2e60223fd9291003da52c910971529cedfd0de95974ec14d34b0e771a74"
    cpu = src.decode().split("// Forward declarations", 1)[1].split("void execute(void)", 1)[0]
    cpu = cpu.replace("static EMU_CLOCK_TYPE next_sleep_time;", "")
    begin = cpu.index("    // Read CPU speed vars")
    end = cpu.index("\n}", begin)
    cpu = cpu[:begin] + cpu[end:]
    begin = cpu.index("NORETURN static void i_halt")
    end = cpu.index("static void do_instruction(uint8_t code)\n{", begin)
    cpu = cpu[:begin] + "static void i_halt(void){__builtin_trap();}\n" + cpu[end:]
    cpu = cpu.replace("    if(debug_active(debug_cpu) && segment_override == NoSeg)\n        debug_instruction();", "")
    (root / "cpu.c").write_text('#include "audio_cpu.h"\n' + cpu + (HERE / "audio_call.c").read_text())
    for src in [HERE / "audio_cpu.h", HERE / "emu2/cpu.h", HERE / "opl.cpp",
                args.dbopl / "dbopl.h", args.dbopl / "dbopl.cpp", args.dbopl / "adlib.h"]:
        shutil.copyfile(src, root / src.name)
    (root / "dosbox.h").write_text((HERE / "dosbox_web.h").read_text())
    # Only libm table initializers need host functions. There are no WASI
    # imports, runtime allocations, OS calls, or cross-origin dependencies.
    (root / "math.h").write_text('extern "C" double sin(double),pow(double,double);\n')
    (root / "stdlib.h").write_text("static inline long labs(long n) { return n < 0 ? -n : n; }")
    (root / "string.h").write_text('extern "C" void *memset(void*,int,__SIZE_TYPE__);\n')
    subprocess.run([args.zig, "cc", "-target", "wasm32-freestanding", "-O2", "-I.", "-c", "cpu.c", "-o", "cpu.o"], cwd=root, check=True)
    for unit in ("dbopl", "opl"):
        subprocess.run([args.zig, "c++", "-target", "wasm32-freestanding", "-O2", "-nostdlib", "-I.",
                        "-fno-exceptions", "-fno-rtti", "-fno-threadsafe-statics", "-fno-sanitize=undefined",
                        "-c", unit+".cpp", "-o", unit+".o"], cwd=root, check=True)
    subprocess.run([args.zig, "build-exe", "-target", "wasm32-freestanding", "-O", "ReleaseFast",
                    "dbopl.o", "opl.o", "cpu.o", "-fno-entry", "--import-symbols", "-fstrip",
                    *["--export="+n for n in ("audio_mem","audio_init","audio_call","audio_render")],
                    "-femit-bin=" + str(args.out / "ftoons_audio.wasm")], cwd=root, check=True)

with zipfile.ZipFile(args.out / "ftoons_audio_source.zip", "w", zipfile.ZIP_DEFLATED) as z:
    for src in HERE.rglob("*"):
        if not src.is_file() or args.out.resolve() in src.parents or (HERE / "dbopl") in src.parents: continue
        if src.suffix in (".py", ".h", ".c", ".cpp", ".md") or src.name == "COPYING": z.write(src, src.relative_to(HERE))
    for name in ("dbopl.h", "dbopl.cpp", "adlib.h", "COPYING"): z.write(args.dbopl / name, "dbopl/" + name)
